# VÁ Bar Inventory — setup guide

A working staff inventory app: real login, real database, mobile-friendly.
No coding needed to get it live — just follow the steps below in order.

## What it's built on
- **The app itself**: a single web page (`index.html`) — works on any phone or laptop browser.
- **Login + database**: [Supabase](https://supabase.com) (free tier is enough for 5 staff and a bar's worth of inventory).
- **Hosting**: [Netlify](https://netlify.com) (free) — this is what your domain will point to.

## Step 1 — Create your Supabase project
1. Go to supabase.com → sign up → **New project**.
2. Name it `vabar-inventory`, set a database password (save it somewhere), pick a region (EU if available, closest to Iceland).
3. Once it's created, open **SQL Editor** → **New query**, paste in the contents of `schema.sql` (included here), and run it. This creates the inventory table and locks it so only signed-in staff can see or edit it.

## Step 2 — Add your 5 staff as users
1. In Supabase, go to **Authentication → Users → Add user**.
2. Add one row per person (you, Dianna, Jofred, Ivan, Matt) with their email and a temporary password.
3. Tell each person their temporary password — they can change it later from Supabase's password-reset flow, or just keep it if that's simpler for now.

## Step 3 — Connect the app to your project
1. In Supabase: **Project Settings → API**.
2. Copy the **Project URL** and the **anon public** key.
3. Open `config.js` (included here) and paste them in:
   ```js
   window.VABAR_CONFIG = {
     SUPABASE_URL: "https://xxxxx.supabase.co",
     SUPABASE_ANON_KEY: "eyJhbGciOi...",
   };
   ```

## Step 4 — Put it online
1. Go to [app.netlify.com](https://app.netlify.com) → sign up (free) → **Add new site → Deploy manually**.
2. Drag the whole `vabar-inventory` folder (with your edited `config.js`) into the upload box.
3. Netlify gives you a temporary link like `vabar-inventory-xyz.netlify.app` — open it and test signing in with one of the staff accounts.

## Step 5 — Connect VabarInventory.is
1. Buy the domain (any registrar — Namecheap, GoDaddy, or an Icelandic registrar like ISNIC for `.is` domains).
2. In Netlify: **Site settings → Domain management → Add a domain** → enter `vabarinventory.is`.
3. Netlify will show you DNS records to add at your registrar (usually one A record + one CNAME). Add those in your registrar's DNS settings.
4. Wait for DNS to propagate (usually under an hour, sometimes up to 24h) — then `vabarinventory.is` loads the app directly.

## Using the app day to day
- Anyone signs in with their email + password.
- Quantities can be edited right in the table — changes save automatically and stamp who made the change and when.
- **+ Add item** for new products; the ✎ and ✕ icons edit or remove an item.
- Set a **par level** on any item to get a low-stock flag (Á) when it drops to or below that number.
- Category tabs (Spirits / Wine / Beer / Mixers / Food / Other) filter the list.

## What's next (when you're ready)
- Barcode scanning: can be added using the phone camera (no extra hardware) — say the word when you want it.
- CSV export for month-end counts.
- A read-only "manager" view vs. full-edit staff view, if you want to restrict who can delete items.
